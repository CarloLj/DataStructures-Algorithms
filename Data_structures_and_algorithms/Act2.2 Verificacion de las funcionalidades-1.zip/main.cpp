#include <iostream>
#include <vector>
#include <string>

#include "valid_parentheses.cpp"
using namespace std;

int main(){
  //cout << isPalindrome(121);
  //cout << reverse(12345);
  //cout << isValid("()()}");
  //cout << isValid("()()");
  return 0;
}
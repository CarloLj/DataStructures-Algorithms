#include <iostream>

using namespace std;

template <class T> class Node {
    private:
        T data; // The object information
        Node* next; // Pointer to the next node element

    public:
        Node(T new_data, Node* next_node){
            this->data = new_data;
            this->next = next_node;
        }

        Node(T new_data){
            this->data = new_data;
            this->next = NULL;
        }

        void set_data(T new_data){
            this->data = new_data;
        }

        T get_data(){
            return this->data;
        }

        void set_next(Node *next_node){
            this->next = next_node;
        }

        Node* get_next(){
            return this->next;
        }
};


template <class T> class CustomLinkedList{
    public:
        Node<T> *head;
        
        CustomLinkedList(){
            head = NULL;
        }

        ~CustomLinkedList(){

        }

        // Method adds data to the end of the list
        void add_begin(T data){
            Node<T>* temp = new Node<T>(data, head);
            this->head = temp;
        }
        
        void delete_end(){
            Node<T> *temp = this->head;
            this->head = this->head->get_next();
            delete temp;
        }
};




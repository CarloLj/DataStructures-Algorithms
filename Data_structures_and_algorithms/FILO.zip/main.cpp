#include <iostream>
#include "ligadas.cpp"

using namespace std;

template<class T> class Stack{
  private:
    CustomLinkedList<T> lista;
    T nulo;
  public:
    Stack(){}
    void push(T data){
      lista.add_begin(data);
    }
    
    void pop(){
      if (lista.head) {
        lista.delete_end();
      }
    }
    
    bool is_empty(){
      if (lista.head == NULL) return true; 
      else return false;
    }

    T top(){
      if (lista.head != NULL) {
        return lista.head->get_data();
      }
      else return nulo;
			
    }
};

int main(){
    Stack<int> pila;
    cout<<pila.top();
    // cout<<pila.top;
    // pila.push(20);
    // pila.push(30);
    // pila.push(40);
    // cout << pila.top();
    // pila.pop();
    // cout << endl;
    // cout << pila.top();
    // pila.pop();
    // cout << endl;
    // cout << pila.top();
    // pila.pop();
    // cout << endl;
    // cout << pila.top();
    // pila.pop();
       //cout<<"TONCES Q RETORNAMOS SI NO SE PUEDE EL NULL";
    return 0;
}